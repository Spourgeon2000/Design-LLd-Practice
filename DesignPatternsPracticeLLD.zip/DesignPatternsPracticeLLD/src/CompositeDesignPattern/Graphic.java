package CompositeDesignPattern;

public interface Graphic {
    public void draw();
}
