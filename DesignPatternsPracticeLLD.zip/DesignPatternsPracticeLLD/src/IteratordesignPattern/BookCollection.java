package IteratordesignPattern;

public interface BookCollection {
    Iterator<Book> createIterator();
}