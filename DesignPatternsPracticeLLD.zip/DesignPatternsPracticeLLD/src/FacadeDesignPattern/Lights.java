package FacadeDesignPattern;

public class Lights {
    public void dim(int level) {
        System.out.println("Lights are dimmed to " + level + "%.");
    }
}