package NullObjectDesignPattern;

public interface Customer {
    String getName();
    boolean isNull();
}