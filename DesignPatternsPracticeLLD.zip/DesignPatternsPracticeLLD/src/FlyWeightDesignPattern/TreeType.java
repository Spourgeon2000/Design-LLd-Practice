package FlyWeightDesignPattern;

public interface TreeType {
    void display(int x, int y);
}