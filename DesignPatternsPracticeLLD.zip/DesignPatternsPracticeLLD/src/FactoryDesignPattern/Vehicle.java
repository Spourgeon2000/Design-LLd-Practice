package FactoryDesignPattern;

public interface Vehicle {
    public void drive();
}
