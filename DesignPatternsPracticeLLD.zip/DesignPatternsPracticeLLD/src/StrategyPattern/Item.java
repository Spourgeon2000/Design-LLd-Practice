package StrategyPattern;

public class Item {
    public int price;
    public String name;
    public Item(int price,String name){
        this.name = name;
        this.price = price;
    }
}
