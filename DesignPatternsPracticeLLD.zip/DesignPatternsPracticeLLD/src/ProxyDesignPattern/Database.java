package ProxyDesignPattern;

public interface Database {
    public void fetchData();
}
