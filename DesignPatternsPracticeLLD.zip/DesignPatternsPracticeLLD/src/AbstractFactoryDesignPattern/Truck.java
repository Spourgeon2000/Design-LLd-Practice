package AbstractFactoryDesignPattern;

public interface Truck {
    void drive();
}
