package AbstractFactoryDesignPattern;

public interface Car {
    void drive();
}