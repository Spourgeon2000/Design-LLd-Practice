package InterpretDesignPattern;

public interface Expression {
    int interpret();
}
