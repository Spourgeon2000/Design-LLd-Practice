package CommandDesignPattern;

public interface Command {
    void execute();
}
